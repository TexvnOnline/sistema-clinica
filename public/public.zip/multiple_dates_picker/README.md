MultiDatesPicker for jQuery UI
==============================

Find more on the [official MDP page](https://dubrox.github.io/Multiple-Dates-Picker-for-jQuery-UI).

**CAUTION**: 1.6.x has changes to methods and options that are incompatible with 
previous versions of the same methods.